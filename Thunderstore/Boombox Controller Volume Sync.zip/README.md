# BoomboxControllerVolumeSync
 Lethal Company mod that adds volume synchronization to Boombox Controller mod.
